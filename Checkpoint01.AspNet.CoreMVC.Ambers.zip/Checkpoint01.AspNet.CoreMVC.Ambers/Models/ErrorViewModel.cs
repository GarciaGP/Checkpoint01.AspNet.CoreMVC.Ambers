using System;

namespace Checkpoint01.AspNet.CoreMVC.Ambers.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
